import API from "../../api";

export const fuzzyMatch = (input, target) => {
  if (!input || !target) return false;
  const normInput = input.toLowerCase().trim();
  const normTarget = target.toLowerCase().trim();
  if (normTarget === normInput) return true;
  if (normTarget.includes(normInput) || normInput.includes(normTarget)) return true;
  const inputWords = normInput.split(/\s+/);
  const targetWords = normTarget.split(/\s+/);
  const matchedWords = inputWords.filter(w => targetWords.some(tw => tw.includes(w) || w.includes(tw)));
  return matchedWords.length / inputWords.length >= 0.6;
};

// Sport booking step handling
export const handleSportBooking = async (userInput, bookingStep, bookingData, sportsList, user, navigate, addMessage, resetBooking, setIsOpen) => {
  const lower = userInput.toLowerCase();

  if (!bookingStep) {
    if (lower.includes("book a sport") || lower === "book sport" || lower === "book") {
      if (sportsList.length === 0) {
        addMessage("ai", "Loading sports data... Please try again in a moment.");
        return { newStep: null, newData: {} };
      }
      addMessage("ai", `Which sport would you like to book? Here are our available sports:\n${sportsList.map(s => s.name).join(", ")}\n\nPlease reply with the sport name.`);
      return { newStep: "sport", newData: bookingData };
    }
    return null;
  }

  // Step: sport
  if (bookingStep === "sport") {
    const sport = sportsList.find(s => fuzzyMatch(userInput, s.name));
    if (!sport) {
      addMessage("ai", `Sorry, I don't recognise "${userInput}". Available sports: ${sportsList.map(s => s.name).join(", ")}. Please try again.`);
      return { newStep: "sport", newData: bookingData };
    }
    const newData = { sportId: sport._id, sportName: sport.name, price: sport.price };
    addMessage("ai", `Great choice! ${sport.name} costs ${sport.price} EGP per session. Do you want to proceed to payment? (yes/no)`);
    return { newStep: "confirm", newData };
  }

  // Step: confirm
  if (bookingStep === "confirm") {
    if (userInput.toLowerCase() === "yes" || userInput.toLowerCase() === "y") {
      const userStored = JSON.parse(localStorage.getItem("user"));
      if (!userStored) {
        addMessage("ai", "You need to log in first. Please log in and try again.");
        resetBooking();
        return { newStep: null, newData: {} };
      }
      navigate("/payment", {
        state: {
          bookingData: {
            userId: userStored._id,
            sportId: bookingData.sportId,
            sportName: bookingData.sportName,
            coach: "Any Coach",
            day: "Flexible",
            time: "Flexible",
            price: bookingData.price,
          },
        },
      });
      addMessage("ai", "Redirecting to payment... Complete the payment to confirm your booking.");
      resetBooking();
      setIsOpen(false);
      return { newStep: null, newData: {} };
    } else {
      addMessage("ai", "Alright, booking cancelled. You can start over by saying 'book a sport'.");
      resetBooking();
      return { newStep: null, newData: {} };
    }
  }
  return null;
};

// Event joining logic
export const handleEventJoin = async (userInput, bookingStep, bookingData, eventsList, user, navigate, addMessage, resetBooking, setIsOpen) => {
  if (!bookingStep || bookingStep !== "event_select") {
    if (userInput.toLowerCase().includes("join an event") || userInput.toLowerCase().includes("join event")) {
      if (eventsList.length === 0) {
        addMessage("ai", "Loading events... Please try again in a moment.");
        return { newStep: null, newData: {} };
      }
      const numberedEvents = eventsList.map((e, idx) => 
        `${idx+1}. ${e.title} (${new Date(e.date).toLocaleDateString()}) - ${e.price} EGP`
      ).join("\n");
      addMessage("ai", `Which event would you like to join? Here are upcoming events:\n${numberedEvents}\n\nPlease reply with the number (e.g., "1") or the event name.`);
      return { newStep: "event_select", newData: {} };
    }
    return null;
  }

  if (bookingStep === "event_select") {
    let selectedEvent = null;
    const numericMatch = userInput.match(/^\d+$/);
    if (numericMatch) {
      const idx = parseInt(numericMatch[0], 10) - 1;
      if (idx >= 0 && idx < eventsList.length) {
        selectedEvent = eventsList[idx];
      }
    }
    if (!selectedEvent) {
      selectedEvent = eventsList.find(e => fuzzyMatch(userInput, e.title));
    }
    if (!selectedEvent) {
      const numberedEvents = eventsList.map((e, idx) => 
        `${idx+1}. ${e.title} (${new Date(e.date).toLocaleDateString()})`
      ).join("\n");
      addMessage("ai", `Sorry, I don't recognise "${userInput}". Here are the events again:\n${numberedEvents}\n\nPlease reply with the number (e.g., "1") or the event name.`);
      return { newStep: "event_select", newData: {} };
    }
    const userStored = JSON.parse(localStorage.getItem("user"));
    if (!userStored) {
      addMessage("ai", "You need to log in first.");
      resetBooking();
      return { newStep: null, newData: {} };
    }
    addMessage("ai", `Great choice! "${selectedEvent.title}" costs ${selectedEvent.price} EGP. Do you want to confirm your registration? (yes/no)`);
    return { newStep: "event_confirm", newData: { selectedEvent } };
  }

  if (bookingStep === "event_confirm") {
    if (userInput.toLowerCase() === "yes" || userInput.toLowerCase() === "y") {
      const userStored = JSON.parse(localStorage.getItem("user"));
      try {
        await API.post(`/events/${bookingData.selectedEvent._id}/register`, {
          userId: userStored._id,
          userName: userStored.name
        });
        addMessage("ai", `✅ Successfully registered for "${bookingData.selectedEvent.title}"! You can view it in your schedule.`);
        resetBooking();
        setIsOpen(false);
        return { newStep: null, newData: {} };
      } catch (err) {
        addMessage("ai", err.response?.data?.message || "Sorry, registration failed. Please try again.");
        resetBooking();
        return { newStep: null, newData: {} };
      }
    } else {
      addMessage("ai", "Registration cancelled. You can say 'join an event' anytime to try again.");
      resetBooking();
      return { newStep: null, newData: {} };
    }
  }
  return null;
};

// Program enrollment logic
export const handleProgramEnroll = async (userInput, bookingStep, bookingData, programsList, user, navigate, addMessage, resetBooking, setIsOpen) => {
  if (!bookingStep || bookingStep !== "program_select") {
    if (userInput.toLowerCase().includes("enroll in program") || userInput.toLowerCase().includes("join program")) {
      if (programsList.length === 0) {
        addMessage("ai", "Loading programs... Please try again in a moment.");
        return { newStep: null, newData: {} };
      }
      const numberedPrograms = programsList.map((p, idx) => 
        `${idx+1}. ${p.name} - ${p.duration} - ${p.price} EGP`
      ).join("\n");
      addMessage("ai", `Which program would you like to enroll in? Here are our programs:\n${numberedPrograms}\n\nPlease reply with the number (e.g., "1") or the program name.`);
      return { newStep: "program_select", newData: {} };
    }
    return null;
  }

  if (bookingStep === "program_select") {
    let selectedProgram = null;
    const numericMatch = userInput.match(/^\d+$/);
    if (numericMatch) {
      const idx = parseInt(numericMatch[0], 10) - 1;
      if (idx >= 0 && idx < programsList.length) {
        selectedProgram = programsList[idx];
      }
    }
    if (!selectedProgram) {
      selectedProgram = programsList.find(p => fuzzyMatch(userInput, p.name));
    }
    if (!selectedProgram) {
      const numberedPrograms = programsList.map((p, idx) => 
        `${idx+1}. ${p.name} - ${p.duration}`
      ).join("\n");
      addMessage("ai", `Sorry, I don't recognise "${userInput}". Here are our programs again:\n${numberedPrograms}\n\nPlease reply with the number or program name.`);
      return { newStep: "program_select", newData: {} };
    }
    const userStored = JSON.parse(localStorage.getItem("user"));
    if (!userStored) {
      addMessage("ai", "You need to log in first.");
      resetBooking();
      return { newStep: null, newData: {} };
    }
    addMessage("ai", `Great! "${selectedProgram.name}" costs ${selectedProgram.price} EGP. Do you want to confirm your enrollment? (yes/no)`);
    return { newStep: "program_confirm", newData: { selectedProgram } };
  }

  if (bookingStep === "program_confirm") {
    if (userInput.toLowerCase() === "yes" || userInput.toLowerCase() === "y") {
      const userStored = JSON.parse(localStorage.getItem("user"));
      try {
        await API.post(`/programs/${bookingData.selectedProgram._id}/enroll`, {
          userId: userStored._id,
          userName: userStored.name,
          programId: bookingData.selectedProgram._id,
          programName: bookingData.selectedProgram.name,
          coach: bookingData.selectedProgram.coach || "Professional Coach",
          duration: bookingData.selectedProgram.duration,
          price: bookingData.selectedProgram.price,
          schedule: bookingData.selectedProgram.schedule || "Flexible"
        });
        addMessage("ai", `✅ Successfully enrolled in "${bookingData.selectedProgram.name}"! You can view it in your dashboard.`);
        resetBooking();
        setIsOpen(false);
        return { newStep: null, newData: {} };
      } catch (err) {
        addMessage("ai", err.response?.data?.message || "Sorry, enrollment failed. Please try again.");
        resetBooking();
        return { newStep: null, newData: {} };
      }
    } else {
      addMessage("ai", "Enrollment cancelled. You can say 'enroll in program' anytime to try again.");
      resetBooking();
      return { newStep: null, newData: {} };
    }
  }
  return null;
};

// General response - Fixed syntax error
export const getGeneralResponse = (userMsg, sportsList, eventsList, programsList) => {
  const lower = userMsg.toLowerCase().trim();

  // Greetings
  if (lower.includes("hi") || lower.includes("hello") || lower.includes("hey")) {
    return "Hello! 👋 I'm your Pegasus Club assistant. I can help you book sports, join events, enroll in programs, or answer questions. What would you like to do today?";
  }

  if (lower.includes("how are you")) {
    return "I'm doing great, thank you for asking! 🌟 Ready to help you with your sports and fitness journey at Pegasus Club!";
  }

  if (lower.includes("thank you") || lower.includes("thanks")) {
    return "You're very welcome! 😊 Is there anything else I can help you with?";
  }

  // Sports
  if (lower === "sports" || lower === "list sports" || lower === "show sports") {
    if (sportsList.length) {
      const numbered = sportsList.map((s, idx) => `${idx+1}. ${s.name} - ${s.price} EGP`).join("\n");
      return `Here are the available sports at Pegasus Club:\n${numbered}\n\nWould you like to book one? Say "book a sport" to get started.`;
    }
    return "No sports available at the moment. Please check back later!";
  }

  // Events
  if (lower === "events" || lower === "list events" || lower === "show events") {
    if (eventsList.length) {
      const numbered = eventsList.map((e, idx) => `${idx+1}. ${e.title} on ${new Date(e.date).toLocaleDateString()} - ${e.price} EGP`).join("\n");
      return `Upcoming events at Pegasus Club:\n${numbered}\n\nSay "join an event" to register for one!`;
    }
    return "No upcoming events at the moment. Stay tuned for exciting events!";
  }

  // Programs
  if (lower === "programs" || lower === "list programs" || lower === "show programs") {
    if (programsList.length) {
      const numbered = programsList.map((p, idx) => `${idx+1}. ${p.name} - ${p.duration} - ${p.price} EGP`).join("\n");
      return `Here are our training programs:\n${numbered}\n\nSay "enroll in program" to join one!`;
    }
    return "No programs available at the moment. Check back soon!";
  }

  // Price inquiries
  if (lower.includes("price") || lower.includes("cost")) {
    return "Prices vary by activity:\n• Sports sessions: 50-200 EGP\n• Events: 20-100 EGP\n• Programs: 80-200 EGP\n\nYou can check specific prices on each page or ask me about a specific sport!";
  }

  // Schedule / My bookings
  if (lower.includes("schedule") || lower.includes("my booking") || lower.includes("my schedule")) {
    return "You can view all your bookings, event registrations, and program enrollments in the Schedule page from the sidebar menu! 📅";
  }

  // Cancel booking
  if (lower.includes("cancel")) {
    return "You can cancel your sport bookings, event registrations, or program enrollments from your Schedule page. Just click the 'Cancel' button next to the item you want to cancel. ⚠️ Note: Cancellations are final.";
  }

  // Contact / Info
  if (lower.includes("contact") || lower.includes("phone") || lower.includes("email")) {
    return "You can reach Pegasus Club at:\n📞 Phone: +20 123 456 789\n📧 Email: info@pegasusclub.com\n📍 Location: New Cairo, Egypt";
  }

  if (lower.includes("about")) {
    return "Pegasus Club is a premier sports and fitness destination offering professional training, exciting events, and comprehensive programs for all ages. We're dedicated to helping you achieve your fitness goals! 🦄✨";
  }

  // Help
  if (lower.includes("help") || lower === "what can you do") {
    return "I can help you with:\n🔹 Book a sport (say 'book a sport')\n🔹 Join an event (say 'join an event')\n🔹 Enroll in a program (say 'enroll in program')\n🔹 List available sports, events, or programs\n🔹 Answer questions about prices, schedule, and more!\n\nWhat would you like to do today?";
  }

  // Default response
  return "I can help you book sports, join events, or enroll in programs! Try saying:\n• 'book a sport'\n• 'join an event'\n• 'enroll in program'\n• 'sports', 'events', or 'programs'\n• 'help' for more options\n\nWhat can I assist you with today? 🦄";
};